ORDER LINKER — Installable PWA

1. Put these files on an HTTPS web host.
2. Open the site in Chrome on Android.
3. Chrome menu -> Add to Home screen / Install app.
4. The app opens in standalone full-screen mode.

The prototype currently uses demo Uber/PickMe orders.
Live platform integration requires official API access and permission from the respective platforms.
